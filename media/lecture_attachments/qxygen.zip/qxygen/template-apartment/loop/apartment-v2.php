<?php
global $post;
?>
<article <?php post_class('apartment-v2'); ?>>	
	<?php if ( has_post_thumbnail() ) { ?>
		<div class="apartment-thumb">
			<a class="apartment-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
				<?php the_post_thumbnail( 'qxygen-blog-grid', array( 'alt' => get_the_title() ) ); ?>
				<span class="apartment-more">
					<i class="flaticon-right-arrow"></i>
				</span>
			</a>
		</div>
	<?php } ?>
	<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h3>' ); ?>
</article>