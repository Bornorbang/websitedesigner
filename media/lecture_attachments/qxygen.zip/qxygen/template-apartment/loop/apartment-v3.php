<?php
global $post;
$action_img = qxygen_get_config('apartments_action_image');
?>
<article <?php post_class('apartment-v3'); ?>>	
	<?php if ( has_post_thumbnail() ) { ?>
		<div class="apartment-thumb p-relative">
			<a class="apartment-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
				<?php the_post_thumbnail( 'qxygen-blog-grid', array( 'alt' => get_the_title() ) ); ?>
			</a>
			<div class="meta-bottom flex-middle">
				<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h3>' ); ?>
				<div class="ali-right">
					<a class="apartment-more" href="<?php the_permalink(); ?>">
						<i class="flaticon-right-arrow"></i>
					</a>
				</div>
			</div>
		</div>
	<?php } ?>
	<?php if ( !has_post_thumbnail() ) { ?>
		<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h3>' ); ?>
	<?php } ?>
	<?php if ( isset($action_img['url']) && !empty($action_img['url']) && has_post_thumbnail() ) { ?>
		<div class="action" style="background-image:url('<?php echo esc_url($action_img['url']);?>');" > </div>
	<?php } ?>
</article>