<?php
global $post;
$action_img = qxygen_get_config('apartments_action_image');
?>
<article <?php post_class('apartment-v1'); ?>>	
	<?php if ( has_post_thumbnail() ) { ?>
		<div class="apartment-thumb">
			<a class="apartment-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
				<?php the_post_thumbnail( 'qxygen-blog-grid', array( 'alt' => get_the_title() ) ); ?>
				<span class="apartment-more">
					<i class="flaticon-right-arrow"></i>
				</span>
			</a>
		</div>
	<?php } ?>
	<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h3>' ); ?>
	<?php if ( isset($action_img['url']) && !empty($action_img['url']) && has_post_thumbnail() ) { ?>
		<div class="action" style="background-image:url('<?php echo esc_url($action_img['url']);?>');" > </div>
	<?php } ?>
</article>