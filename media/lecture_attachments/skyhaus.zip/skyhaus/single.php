<?php
/**
 * The template for displaying all single posts.
 *
 * @package skyhaus
 */
get_header();

do_action( 'skyhaus_before_main_content' );

get_template_part('templates/content/templates/content-single');

do_action( 'skyhaus_after_main_content' );

get_footer();