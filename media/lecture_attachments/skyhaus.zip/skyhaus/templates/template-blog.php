<?php
/*
* Template Name: Blog
*/
get_header();

do_action( 'skyhaus_before_main_content' );

get_template_part('templates/content/templates/content-blog');

do_action( 'skyhaus_after_main_content' );

get_footer();