<a class="skyhaus-back-to-top skyhaus-is-visible skyhaus-fade-out" href="<?php echo esc_url('#0'); ?>">
    <i class="fas fa-angle-up"></i>
</a>