<div class="skyhaus-post-metas">
    <div class="skyhaus-article-details">
        <?php get_template_part('templates/content/templates/sections/list/post-author' ); ?>
        <?php get_template_part('templates/content/templates/sections/list/post-category' ); ?>
        <?php get_template_part('templates/content/templates/sections/list/post-date' ); ?>
    </div>
</div>