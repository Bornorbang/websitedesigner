<div class="clearfix"></div>
<div class="skyhaus-read-more-holder">
    <a href="<?php echo esc_url(get_the_permalink()); ?>" class="skyhaus-more-link">
        <?php echo esc_html__( 'Read More', 'skyhaus' ); ?>
    </a>
</div>