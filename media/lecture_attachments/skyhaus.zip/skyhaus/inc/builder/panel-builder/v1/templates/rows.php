<script type="text/html" id="tmpl-skyhaus--cb-panel">
	<div class="skyhaus--cp-rows">

		<# if ( ! _.isUndefined( data.rows.top ) ) { #>
		<div class="skyhaus--row-top skyhaus--cb-row" data-id="{{ data.id }}_top">
			<a class="skyhaus--cb-row-settings" title="{{ data.rows.top }}" data-id="top" href="#"></a>
			<div class="skyhaus--row-inner">
				<div class="row--grid">
					<?php
					for ( $i = 1; $i <= 12; $i ++ ) {
						echo '<div></div>';
					}
					?>
				</div>
				<div class="skyhaus--cb-items grid-stack gridster" data-id="top"></div>
			</div>
		</div>
		<# } #>

		<# if ( ! _.isUndefined( data.rows.main ) ) { #>
		<div class="skyhaus--row-main skyhaus--cb-row" data-id="{{ data.id }}_main">
			<a class="skyhaus--cb-row-settings" title="{{ data.rows.main }}" data-id="main" href="#"></a>

			<div class="skyhaus--row-inner">
				<div class="row--grid">
					<?php
					for ( $i = 1; $i <= 12; $i ++ ) {
						echo '<div></div>';
					}
					?>
				</div>
				<div class="skyhaus--cb-items grid-stack gridster" data-id="main"></div>
			</div>
		</div>
		<# } #>


		<# if ( ! _.isUndefined( data.rows.bottom ) ) { #>
		<div class="skyhaus--row-bottom skyhaus--cb-row" data-id="{{ data.id }}_bottom">
			<a class="skyhaus--cb-row-settings" title="{{ data.rows.bottom }}" data-id="bottom" href="#"></a>
			<div class="skyhaus--row-inner">
				<div class="row--grid">
					<?php
					for ( $i = 1; $i <= 12; $i ++ ) {
						echo '<div></div>';
					}
					?>
				</div>
				<div class="skyhaus--cb-items grid-stack gridster" data-id="bottom"></div>
			</div>
		</div>
		<# } #>
	</div>


	<# if ( data.device != 'desktop' ) { #>
		<# if ( ! _.isUndefined( data.rows.sidebar ) ) { #>
		<div class="skyhaus--cp-sidebar">
			<div class="skyhaus--row-bottom skyhaus--cb-row" data-id="{{ data.id }}_sidebar">
				<a class="skyhaus--cb-row-settings" title="{{ data.rows.sidebar }}" data-id="sidebar" href="#"></a>
				<div class="skyhaus--row-inner">
					<div class="skyhaus--cb-items skyhaus--sidebar-items" data-id="sidebar"></div>
				</div>
			</div>
			<div>
		<# } #>
	<# } #>

</script>
