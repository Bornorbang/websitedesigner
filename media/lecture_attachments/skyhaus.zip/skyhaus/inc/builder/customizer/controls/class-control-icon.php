<?php
class Skyhaus_Customizer_Control_Icon extends Skyhaus_Customizer_Control_Base {
	static function field_template() {
		echo '<script type="text/html" id="tmpl-field-skyhaus-icon">';
		self::before_field();
		?>
		<#
		if ( ! _.isObject( field.value ) ) {
			field.value = { };
		}
		#>
		<?php echo self::field_header(); ?>
		<div class="skyhaus-field-settings-inner">
			<div class="skyhaus--icon-picker">
				<div class="skyhaus--icon-preview">
					<input type="hidden" class="skyhaus-input skyhaus--input-icon-type" data-name="{{ field.name }}-type" value="{{ field.value.type }}">
					<div class="skyhaus--icon-preview-icon skyhaus--pick-icon">
						<# if ( field.value.icon ) {  #>
							<i class="{{ field.value.icon }}"></i>
						<# }  #>
					</div>
				</div>
				<input type="text" readonly class="skyhaus-input skyhaus--pick-icon skyhaus--input-icon-name" placeholder="<?php esc_attr_e( 'Pick an icon', 'skyhaus' ); ?>" data-name="{{ field.name }}" value="{{ field.value.icon }}">
				<span class="skyhaus--icon-remove" title="<?php esc_attr_e( 'Remove', 'skyhaus' ); ?>">
					<span class="dashicons dashicons-no-alt"></span>
					<span class="screen-reader-text">
					<?php _e( 'Remove', 'skyhaus' ); ?></span>
				</span>
			</div>
		</div>
		<?php
		self::after_field();
		echo '</script>';
		?>
		<div id="skyhaus--sidebar-icons">
			<div class="skyhaus--sidebar-header">
				<a class="customize-controls-icon-close" href="#">
					<span class="screen-reader-text"><?php _e( 'Cancel', 'skyhaus' ); ?></span>
				</a>
				<div class="skyhaus--icon-type-inner">
					<select id="skyhaus--sidebar-icon-type">
						<option value="all"><?php _e( 'All Icon Types', 'skyhaus' ); ?></option>
					</select>
				</div>
			</div>
			<div class="skyhaus--sidebar-search">
				<input type="text" id="skyhaus--icon-search" placeholder="<?php esc_attr_e( 'Type icon name', 'skyhaus' ); ?>">
			</div>
			<div id="skyhaus--icon-browser"></div>
		</div>
		<?php
	}
}
