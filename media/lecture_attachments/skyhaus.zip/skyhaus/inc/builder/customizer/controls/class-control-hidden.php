<?php
class Skyhaus_Customizer_Control_Hidden extends Skyhaus_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-skyhaus-hidden">
		<?php
		self::before_field();
		?>
		<input type="hidden" class="skyhaus-input skyhaus-only" data-name="{{ field.name }}" value="{{ field.value }}">
		<?php
		self::after_field();
		?>
		</script>
		<?php
	}
}
