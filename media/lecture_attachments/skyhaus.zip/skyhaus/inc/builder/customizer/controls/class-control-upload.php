<?php
class Skyhaus_Customizer_Control_Upload extends Skyhaus_Customizer_Control_Media {
	static function field_template() {
		echo '<script type="text/html" id="tmpl-field-skyhaus-upload">';
		self::before_field();
		?>
		<#
		if ( ! _.isObject(field.value) ) {
			field.value = {};
		}
		var url = field.value.url;
		#>
		<?php echo self::field_header(); ?>
		<div class="skyhaus-field-settings-inner skyhaus-media-type-{{ field.type }}">
			<div class="skyhaus--media">
				<input type="hidden" class="attachment-id" value="{{ field.value.id }}" data-name="{{ field.name }}">
				<input type="hidden" class="attachment-url"  value="{{ field.value.url }}" data-name="{{ field.name }}-url">
				<input type="hidden" class="attachment-mime"  value="{{ field.value.mime }}" data-name="{{ field.name }}-mime">
				<div class="skyhaus-image-preview <# if ( url ) { #> skyhaus--has-file <# } #>" data-no-file-text="<?php esc_attr_e( 'No file selected', 'skyhaus' ); ?>">
					<#

					if ( url ) {
						if ( url.indexOf('http://') > -1 || url.indexOf('https://') ){

						} else {
							url = Skyhaus_Control_Args.home_url + url;
						}

						if ( ! field.value.mime || field.value.mime.indexOf('image/') > -1 ) {
							#>
							<img src="{{ url }}" alt="">
						<# } else if ( field.value.mime.indexOf('video/' ) > -1 ) { #>
							<video width="100%" height="" controls><source src="{{ url }}" type="{{ field.value.mime }}">Your browser does not support the video tag.</video>
						<# } else {
						var basename = url.replace(/^.*[\\\/]/, '');
						#>
							<a href="{{ url }}" class="attachment-file" target="_blank">{{ basename }}</a>
						<# }
					}
					#>
				</div>
				<button type="button" class="button skyhaus--add <# if ( url ) { #> skyhaus--hide <# } #>"><?php _e( 'Add', 'skyhaus' ); ?></button>
				<button type="button" class="button skyhaus--change <# if ( ! url ) { #> skyhaus--hide <# } #>"><?php _e( 'Change', 'skyhaus' ); ?></button>
				<button type="button" class="button skyhaus--remove <# if ( ! url ) { #> skyhaus--hide <# } #>"><?php _e( 'Remove', 'skyhaus' ); ?></button>
			</div>
		</div>

		<?php
		self::after_field();
		echo '</script>';
	}
}
