<?php
class Skyhaus_Customizer_Control_Font extends Skyhaus_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-skyhaus-css-ruler">
		<?php
		self::before_field();
		?>
		<?php echo self::field_header(); ?>
		<div class="skyhaus-field-settings-inner">
			<input type="hidden" class="skyhaus--font-type" data-name="{{ field.name }}-type" >
			<div class="skyhaus--font-families-wrapper">
				<select class="skyhaus--font-families" data-value="{{ JSON.stringify( field.value ) }}" data-name="{{ field.name }}-font"></select>
			</div>
			<div class="skyhaus--font-variants-wrapper">
				<label><?php _e( 'Variants', 'skyhaus' ); ?></label>
				<select class="skyhaus--font-variants" data-name="{{ field.name }}-variant"></select>
			</div>
			<div class="skyhaus--font-subsets-wrapper">
				<label><?php _e( 'Languages', 'skyhaus' ); ?></label>
				<div data-name="{{ field.name }}-subsets" class="list-subsets">
				</div>
			</div>
		</div>
		<?php
		self::after_field();
		?>
		</script>
		<?php
	}
}
