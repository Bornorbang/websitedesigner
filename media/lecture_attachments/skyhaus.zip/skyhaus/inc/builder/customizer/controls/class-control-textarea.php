<?php
class Skyhaus_Customizer_Control_Textarea extends Skyhaus_Customizer_Control_Base {
	static function field_template() {
		echo '<script type="text/html" id="tmpl-field-skyhaus-textarea">';
		self::before_field();
		?>
		<?php echo self::field_header(); ?>
		<div class="skyhaus-field-settings-inner">
			<textarea rows="10" class="skyhaus-input" data-name="{{ field.name }}">{{ field.value }}</textarea>
		</div>
		<?php
		self::after_field();
		echo '</script>';
	}
}
