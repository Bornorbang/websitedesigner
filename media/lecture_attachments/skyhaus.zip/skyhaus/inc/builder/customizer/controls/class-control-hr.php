<?php
class Skyhaus_Customizer_Control_Hr extends Skyhaus_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-skyhaus-hr">
		<?php
		echo '<hr/>';
		?>
		</script>
		<?php
	}
}
