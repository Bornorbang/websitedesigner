<?php
class Skyhaus_Customizer_Control_Typography extends Skyhaus_Customizer_Control_Base {
	static function field_template() {
		echo '<script type="text/html" id="tmpl-field-skyhaus-typography">';
		self::before_field();
		?>
		<?php echo self::field_header(); ?>
		<div class="skyhaus-actions">
			<a href="#" class="action--reset" data-control="{{ field.name }}" title="<?php esc_attr_e( 'Reset to default', 'skyhaus' ); ?>"><span class="dashicons dashicons-image-rotate"></span></a>
			<a href="#" class="action--edit" data-control="{{ field.name }}" title="<?php esc_attr_e( 'Toggle edit panel', 'skyhaus' ); ?>"><span class="dashicons dashicons-editor-textcolor"></span></a>
		</div>
		<div class="skyhaus-field-settings-inner">
			<input type="hidden" class="skyhaus-typography-input skyhaus-only" data-name="{{ field.name }}" value="{{ JSON.stringify( field.value ) }}" data-default="{{ JSON.stringify( field.default ) }}">
		</div>
		<?php
		self::after_field();
		echo '</script>';
		?>
		<div id="skyhaus-typography-panel" class="skyhaus-typography-panel">
			<div class="skyhaus-typography-panel--inner">
				<input type="hidden" id="skyhaus--font-type">
				<div id="skyhaus-typography-panel--fields"></div>
			</div>
		</div>
		<?php
	}
}
