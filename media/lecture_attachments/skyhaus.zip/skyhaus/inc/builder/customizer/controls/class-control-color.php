<?php
class Skyhaus_Customizer_Control_Color extends Skyhaus_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-skyhaus-color">
		<?php
		self::before_field();
		?>
		<?php echo self::field_header(); ?>
		<div class="skyhaus-field-settings-inner">
			<div class="skyhaus-input-color" data-default="{{ field.default }}">
				<input type="hidden" class="skyhaus-input skyhaus-input--color" data-name="{{ field.name }}" value="{{ field.value }}">
				<input type="text" class="skyhaus--color-panel" placeholder="{{ field.placeholder }}" data-alpha="true" value="{{ field.value }}">
			</div>
		</div>
		<?php
		self::after_field();
		?>
		</script>
		<?php
	}
}
