<?php
if ( ! function_exists( 'skyhaus_customizer_styling_config' ) ) {
	function skyhaus_customizer_styling_config( $configs ) {
		$skyhaus_buttons = skyhaus_get_customizer_buttons_styling();
		$skyhaus_buttons_hover = skyhaus_get_customizer_buttons_hover_styling();
		$skyhaus_fields = skyhaus_get_customizer_fields_styling();
		$skyhaus_fields_focus = skyhaus_get_customizer_fields_styling_focus();
		$section = 'skyhaus_styling_settings';
		$config = array(
			array(
				'name'     => 'styling_settings_panel',
				'type'     => 'panel',
				'priority' => 22,
				'title'    => esc_html__( 'Styling Settings', 'skyhaus' ),
			),

			// I. General Tab
			array(
				'name'  => "skyhaus_styling_settings_color",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'General Site Colors', 'skyhaus' ),
			),
			array(
				'name'    		=> 'skyhaus_styling_settings_color_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_styling_settings_color',
				'title'   		=> esc_html__( 'Links Color Option', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_color_links_normal',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_color',
				'selector'   	=> 'format',
				'default'		=> '#222',
				'title'      	=> esc_html__( 'Regular', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_color_links_hover',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_color',
				'selector'   	=> 'format',
				'title'      	=> esc_html__( 'Hover', 'skyhaus' ),
			),
			array(
				'name'    => 'skyhaus_styling_settings_color_links_weight',
				'type'    => 'select',
				'section' => 'skyhaus_styling_settings_color',
				'label'   => esc_html__( 'Weight', 'skyhaus' ),
				'choices' => array(
					'default'   => esc_html__( 'Default', 'skyhaus' ),
					'bold' 		=> esc_html__( 'Bold', 'skyhaus' ),
					'100'  		=> esc_html__( '100', 'skyhaus' ),
					'200'  		=> esc_html__( '200', 'skyhaus' ),
					'300' 		=> esc_html__( '300', 'skyhaus' ),
					'400' 		=> esc_html__( '400', 'skyhaus' ),
					'500' 		=> esc_html__( '500', 'skyhaus' ),
					'600' 		=> esc_html__( '600', 'skyhaus' ),
					'700' 		=> esc_html__( '700', 'skyhaus' ),
					'800' 		=> esc_html__( '800', 'skyhaus' ),
				)
			),

			// 1. Main colors and Background
			array(
				'name'    		=> 'skyhaus_styling_settings_color_bg_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_styling_settings_color',
				'title'   		=> esc_html__( 'Main colors & Background', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_color_text_color',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#2695ff',
				'title'      	=> esc_html__( 'Text color', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_main_bg_color',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#2695ff',
				'title'      	=> esc_html__( 'Background color', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_main_border_color',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#2695ff',
				'title'      	=> esc_html__( 'Border color', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_main_bg_color_hover',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#ffffff',
				'title'      	=> esc_html__( 'Background color (hover)', 'skyhaus' ),
			),

			// 2. Text selection
			array(
				'name'    		=> 'skyhaus_styling_settings_text_selection_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_styling_settings_color',
				'title'   		=> esc_html__( 'Text Selection Color & Background', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_selection_color',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#ffffff',
				'title'      	=> esc_html__( 'Color', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_selection_bg',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#2695ff',
				'title'      	=> esc_html__( 'Background color', 'skyhaus' ),
			),
			array(
				'name'    		=> 'skyhaus_styling_settings_paragraph_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_styling_settings_color',
				'title'   		=> esc_html__( 'Body & Paragraphs Color', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_color_body_color',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_color',
				'selector'    	=> 'body',
				'css_format' 	=> 'color: {{value}};',
				'default'		=> '#6a6b76',
				'title'      	=> esc_html__( 'Color', 'skyhaus' ),
			),

			// 3. Menu Styling Tab
			array(
				'name'  => "skyhaus_styling_settings_navigation",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'Primary Menu Styling', 'skyhaus' ),
			),
			// a. Main Navigation
			array(
				'name'    		=> 'skyhaus_styling_settings_main_navigation_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_styling_settings_navigation',
				'title'   		=> esc_html__( 'Main Navigation', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_main_text_color',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_navigation',
				'selector'   	=> '.builder-item--primary-menu .nav-menu-desktop .menu>li>a',
				'css_format' 	=> 'color: {{value}};',
				'title'      	=> esc_html__( 'Text Color', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_main_text_color_hover',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_navigation',
				'selector'   	=> '.builder-item--primary-menu .nav-menu-desktop .menu>li>a:hover',
				'css_format' 	=> 'color: {{value}};',
				'title'      	=> esc_html__( 'Hover Text Color', 'skyhaus' ),
			),
			// b. Submenu Navigation
			array(
				'name'    		=> 'skyhaus_styling_settings_submenu_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_styling_settings_navigation',
				'title'   		=> esc_html__( 'Submenus Styling', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_submenu_background',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_navigation',
				'selector'    	=> ".nav-menu-desktop .sub-menu li a",
				'css_format' 	=> 'background-color: {{value}};',
				'title'      	=> esc_html__( 'Background Color', 'skyhaus' ),
				'default'   	=> '#FFF',
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_submenu_text_color',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_navigation',
				'selector'    	=> ".nav-menu-desktop .sub-menu li a",
				'css_format' 	=> 'color: {{value}};',
				'title'      	=> esc_html__( 'Text Color', 'skyhaus' ),
				'default'   	=> '#484848',
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_submenu_background_hover',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_navigation',
				'selector'    	=> ".nav-menu-desktop .sub-menu li a:hover",
				'css_format' 	=> 'background-color: {{value}};',
				'title'      	=> esc_html__( 'Hover Background Color', 'skyhaus' ),
				'default'   	=> '#FFF',
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_submenu_text_color_hover',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_navigation',
				'selector'    	=> ".nav-menu-desktop .sub-menu li a:hover",
				'css_format' 	=> 'color: {{value}};',
				'title'      	=> esc_html__( 'Hover Text Color', 'skyhaus' ),
				'default'   	=> '#2695ff',
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_submenu_border_color_hover',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_navigation',
				'selector'    	=> ".nav-menu-desktop .sub-menu li",
				'css_format' 	=> 'border-bottom: 1px solid {{value}} !important;',
				'title'      	=> esc_html__( 'Border Color', 'skyhaus' ),
				'default'   	=> '#ddd',
			),
			array(
				'name'        => 'skyhaus_styling_settings_submenu_padding',
				'type'        => 'styling',
				'section'     => 'skyhaus_styling_settings_navigation',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Styling Items', 'skyhaus' ),
				'selector'    => array(
					'normal'            => ".nav-menu-desktop .sub-menu li a",
					'hover'             => ".nav-menu-desktop .sub-menu li a:hover"
				),
				'fields'      => array(
					'normal_fields' => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
					'hover_fields'  => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
				),
			),
			array(
				'name'        => 'skyhaus_styling_settings_submenu_dropdown',
				'type'        => 'styling',
				'section'     => 'skyhaus_styling_settings_navigation',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Styling Dropdown', 'skyhaus' ),
				'selector'    => array(
					'normal'            => ".nav-menu-desktop .sub-menu",
					'hover'             => ".nav-menu-desktop .sub-menu:hover"
				),
				'fields'      => array(
					'normal_fields' => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
					'hover_fields'  => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
				),
			),

			// Mega Menu
			array(
				'name'  => "skyhaus_styling_settings_mega_menu",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'Mega Menu', 'skyhaus' ),
			),
			// a. Main Navigation
			array(
				'name'    		=> 'skyhaus_styling_settings_mega_menu_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_styling_settings_mega_menu',
				'title'   		=> esc_html__( 'Styling', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_mega_menu_color',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_mega_menu',
				'title'      	=> esc_html__( 'Links Color', 'skyhaus' ),
				'selector'    	=> ".cf-mega-menu.sub-menu a",
				'css_format' 	=> 'color: {{value}};',
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_mega_menu_hover',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_mega_menu',
				'title'      	=> esc_html__( 'Links Hover', 'skyhaus' ),
				'selector'    	=> ".cf-mega-menu.sub-menu a:hover",
				'css_format' 	=> 'color: {{value}};',
			),
			array(
				'name'            => 'skyhaus_styling_settings_mega_menu_width',
				'type'            => 'slider',
				'device_settings' => true,
				'section' 		  => 'skyhaus_styling_settings_mega_menu',
				'selector'        => ".cf-mega-menu.sub-menu",
				'css_format'      => 'width: {{value}};',
				'label'           => esc_html__( 'Width', 'skyhaus' ),
			),

			// III. Buttons Tab
			array(
				'name'  => "skyhaus_styling_settings_buttons",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'Buttons', 'skyhaus' ),
			),
			array(
				'name'        => "skyhaus_styling_settings_buttons_typo",
				'type'        => 'typography',
				'section'     => "skyhaus_styling_settings_buttons",
				'title'       => esc_html__( 'Typography', 'skyhaus' ),
				'description' => esc_html__( 'Apply to buttons text.', 'skyhaus' ),
				'css_format'  => 'typography',
				'selector'    => "{$skyhaus_buttons}",
			), 
			array(
				'name'        => 'skyhaus_styling_settings_buttons_styling',
				'type'        => 'styling',
				'section'     => 'skyhaus_styling_settings_buttons',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Button Styling', 'skyhaus' ),
				'selector'    => array(
					'normal'            => "{$skyhaus_buttons}",
					'hover'             => "{$skyhaus_buttons_hover}",
				),
				'fields'      => array(
					'normal_fields' => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					),
					'hover_fields'  => array(
						'link_color'    => false,
						'padding'       => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'border_radius' => false,
					),
				)
			),
			

			// IV. Fields Tab
			array(
				'name'  => "skyhaus_styling_settings_fields",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'Fields', 'skyhaus' ),
			),
			array(
				'name'        => 'skyhaus_styling_settings_fields_styling',
				'type'        => 'styling',
				'section'     => 'skyhaus_styling_settings_fields',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Fields Styling', 'skyhaus' ),
				'selector'    => array(
					'normal'            => "{$skyhaus_fields}"
				),
				'fields'      => array(
					'normal_fields' => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					)
				)
			),
			array(
				'name'        => "skyhaus_styling_settings_fields_typo",
				'type'        => 'typography',
				'section'     => "skyhaus_styling_settings_fields",
				'title'       => esc_html__( 'Typography', 'skyhaus' ),
				'description' => esc_html__( 'Apply to fields text.', 'skyhaus' ),
				'css_format'  => 'typography',
				'selector'    => "{$skyhaus_fields}",
			),
			array(
				'name'       	=> 'skyhaus_styling_settings_fields_styling_focus',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_styling_settings_fields',
				'selector'    	=> "{$skyhaus_fields_focus}",
				'css_format' 	=> 'border-color: {{value}};',
				'title'      	=> esc_html__( 'Fields Color on Focus', 'skyhaus' ),
				'default'   	=> '#d3d3d3',
			),
			// IV. Typography
			array(
				'name'  => "skyhaus_styling_settings_typo",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'Site Typography', 'skyhaus' ),
			),
			array(
				'name'        => "skyhaus_styling_settings_body_typo",
				'type'        => 'typography',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Body Font family', 'skyhaus' ),
				'css_format'  => 'typography',
				'selector'    => "body, ul li, ol li, p",
			),
			array(
				'name'        => "skyhaus_styling_settings_h1_typo",
				'type'        => 'typography',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H1', 'skyhaus' ),
				'css_format'  => 'typography',
				'selector'    => "h1, h1 span",
			),
			array(
				'name'        => "skyhaus_styling_settings_h2_typo",
				'type'        => 'typography',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H2', 'skyhaus' ),
				'css_format'  => 'typography',
				'selector'    => "h2",
			),
			array(
				'name'        => "skyhaus_styling_settings_h3_typo",
				'type'        => 'typography',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H3', 'skyhaus' ),
				'css_format'  => 'typography',
				'selector'    => "h3, .post-name, .skyhaus-post-name a",
			),
			array(
				'name'        => "skyhaus_styling_settings_h4_typo",
				'type'        => 'typography',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H4', 'skyhaus' ),
				'css_format'  => 'typography',
				'selector'    => "h4",
			),
			array(
				'name'        => "skyhaus_styling_settings_h5_typo",
				'type'        => 'typography',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H5', 'skyhaus' ),
				'css_format'  => 'typography',
				'selector'    => "h5",
			),
			array(
				'name'        => "skyhaus_styling_settings_h6_typo",
				'type'        => 'typography',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H6', 'skyhaus' ),
				'css_format'  => 'typography',
				'selector'    => "h6",
			),
			array(
				'name'    		=> 'skyhaus_styling_settings_mobile_typo_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_styling_settings_typo',
				'title'   		=> esc_html__( 'Mobile Typography', 'skyhaus' ),
			),
			array(
				'name'        => "skyhaus_styling_settings_h1_size_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H1 Font size', 'skyhaus' ),
				'default'	  => '26px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h1_lh_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H1 Line height', 'skyhaus' ),
				'default'	  => '38px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h2_size_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H2 Font size', 'skyhaus' ),
				'default'	  => '24px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h2_lh_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H2 Line height', 'skyhaus' ),
				'default'	  => '28px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h3_size_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H3 Font size', 'skyhaus' ),
				'default'	  => '22px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h3_lh_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H3 Line height', 'skyhaus' ),
				'default'	  => '26px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h4_size_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H4 Font size', 'skyhaus' ),
				'default'	  => '20px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h4_lh_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H4 Line height', 'skyhaus' ),
				'default'	  => '24px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h5_size_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H5 Font size', 'skyhaus' ),
				'default'	  => '18px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h5_lh_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H5 Line height', 'skyhaus' ),
				'default'	  => '22px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h6_size_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H6 Font size', 'skyhaus' ),
				'default'	  => '16px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h6_lh_mobile",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H6 Line height', 'skyhaus' ),
				'default'	  => '20px',
			),
			array(
				'name'    		=> 'skyhaus_styling_settings_tablet_typo_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_styling_settings_typo',
				'title'   		=> esc_html__( 'Tablet Typography', 'skyhaus' ),
			),
			array(
				'name'        => "skyhaus_styling_settings_h1_size_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H1 Font size', 'skyhaus' ),
				'default'	  => '28px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h1_lh_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H1 Line height', 'skyhaus' ),
				'default'	  => '32px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h2_size_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H2 Font size', 'skyhaus' ),
				'default'	  => '26px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h2_lh_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H2 Line height', 'skyhaus' ),
				'default'	  => '30px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h3_size_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H3 Font size', 'skyhaus' ),
				'default'	  => '24px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h3_lh_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H3 Line height', 'skyhaus' ),
				'default'	  => '28px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h4_size_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H4 Font size', 'skyhaus' ),
				'default'	  => '22px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h4_lh_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H4 Line height', 'skyhaus' ),
				'default'	  => '26px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h5_size_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H5 Font size', 'skyhaus' ),
				'default'	  => '20px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h5_lh_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H5 Line height', 'skyhaus' ),
				'default'	  => '23px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h6_size_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H6 Font size', 'skyhaus' ),
				'default'	  => '18px',
			),
			array(
				'name'        => "skyhaus_styling_settings_h6_lh_tablet",
				'type'        => 'text',
				'section'     => "skyhaus_styling_settings_typo",
				'title'       => esc_html__( 'Heading H6 Line height', 'skyhaus' ),
				'default'	  => '21px',
			),

			// IV. Typography
			array(
				'name'  	=> "skyhaus_styling_settings_widgets",
				'type'  	=> 'section',
				'panel' 	=> 'styling_settings_panel',
				'title' 	=> esc_html__( 'Widgets Styling', 'skyhaus' ),
			),
			array(
				'name'    	=> 'skyhaus_styling_widgets_heading_1',
				'type'    	=> 'heading',
				'section' 	=> 'skyhaus_styling_settings_widgets',
				'title'   	=> esc_html__( 'Sidebar Widgets', 'skyhaus' ),
			),
			array(
				'name'        => 'skyhaus_blog_widget_card_styling',
				'type'        => 'styling',
				'section'     => 'skyhaus_styling_settings_widgets',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Card Styling', 'skyhaus' ),
				'selector'    => '.sidebar-content .widget',
				'fields'      => array(
					'normal_fields' => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					)
				)
			),
			array(
				'name'        => 'skyhaus_blog_sidebar_title_styling',
				'type'        => 'typography',
				'section'     => 'skyhaus_styling_settings_widgets',
				'css_format'  => 'typography',
				'title'       => esc_html__( 'Title Typography', 'skyhaus' ),
				'selector'    => '.sidebar-content .widget-title, .sidebar-content .widget h2, .sidebar-content .widget .wp-block-search__label'
			),
			array(
				'name'    		=> 'skyhaus_styling_widgets_social_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_styling_settings_widgets',
				'title'   		=> esc_html__( 'Widget: MT - Contact + Social Media', 'skyhaus' ),
			),
			array(
				'name'        	=> 'skyhaus_widget_contact_styling',
				'type'       	=> 'color',
				'section'     	=> 'skyhaus_styling_settings_widgets',
				'title'       	=> esc_html__( 'Contact Links Styling', 'skyhaus' ),
				'css_format' 	=> 'color: {{value}};',
				'selector'    	=> '.contact-details span, .contact-details span i',
			),
			array(
				'name'        	=> 'skyhaus_widget_social_media_styling',
				'type'        	=> 'styling',
				'section'     	=> 'skyhaus_styling_settings_widgets',
				'css_format'  	=> 'styling',
				'title'       	=> esc_html__( 'Social Icon Styling', 'skyhaus' ),
				'selector'    	=> array(
					'normal'        => ".widget_mt_address_social_icons a",
					'hover'         => ".widget_mt_address_social_icons a:hover",
				),
				'fields'      	=> array(
					'normal_fields' => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					),
					'hover_fields'  => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					)
				)
			)
		);

		return array_merge( $configs, $config );
	}
}

add_filter( 'skyhaus/customizer/config', 'skyhaus_customizer_styling_config' );
