<?php
if ( ! function_exists( 'skyhaus_customizer_general_settings_config' ) ) {
	function skyhaus_customizer_general_settings_config( $configs ) {

		$section = 'skyhaus_general_settings';

		$config = array(
			array(
				'name'     => 'general_settings_panel',
				'type'     => 'panel',
				'priority' => 22,
				'title'    => esc_html__( 'General Settings', 'skyhaus' ),
			),

			// Breadcrumbs
			array(
				'name'  => "skyhaus_general_settings_breadcrumbs",
				'type'  => 'section',
				'panel' => 'general_settings_panel',
				'title' => esc_html__( 'Breadcrumbs', 'skyhaus' ),
			),

			array(
				'name'            => 'skyhaus_enable_breadcrumbs',
				'type'            => 'checkbox',
				'section'         => 'skyhaus_general_settings_breadcrumbs',
				'title'           => esc_html__( 'Breadcrumbs', 'skyhaus' ),
				'description'     => esc_html__('Enable or disable breadcrumbs', 'skyhaus'),
				'default'         => 1
			),
			array(
                'name'       	=> 'skyhaus_breadcrumbs_delimitator',
                'type'     		=> 'text',
				'section'         => 'skyhaus_general_settings_breadcrumbs',
                'title'    		=> esc_html__('Breadcrumbs delimitator', 'skyhaus'),
                'description' 	=> esc_html__('(The theme is also compatible with Breadcrumb NavXT plugin, for an enhanced Breadcrumbs / SEO Ready Breadcrumbs feature. Install it and it will automatically replace the default breadcrumbs feature).', 'skyhaus'),
                'default'  		=> '/'
            ),
			array(
				'name'    		=> 'skyhaus_breadcrumbs_styling_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_general_settings_breadcrumbs',
				'title'   		=> esc_html__( 'Styling', 'skyhaus' ),
			),
			array(
				'name'            => 'skyhaus_breadcrumbs_alignment',
				'type'            => 'text_align_no_justify',
				'section'         => 'skyhaus_general_settings_breadcrumbs',
				'title'           => esc_html__( 'Alignment', 'skyhaus' ),
				'default'		  => 'left'	
			),
			array(
				'name'            => 'skyhaus_breadcrumbs_bg_image',
				'type'            => 'image',
				'section'         => 'skyhaus_general_settings_breadcrumbs',
				'title'           => esc_html__( 'Background', 'skyhaus' ),
				'description' 	  => esc_html__('(Change the background color of the breadcrumbs with an image.)', 'skyhaus'),
				'selector'   	  => ".skyhaus-breadcrumbs, .youzify-search-landing-image-container",
				'css_format' 	  => 'background-image: url({{value}});',
			),
			array(
				'name'            => 'skyhaus_enable_parallax',
				'type'            => 'checkbox',
				'section'         => 'skyhaus_general_settings_breadcrumbs',
				'title'           => esc_html__( 'Parallax', 'skyhaus' ),
				'description'     => esc_html__('Parallax on background', 'skyhaus'),
				'default'         => 0
			),
			array(
				'name'        => 'skyhaus_breadcrumbs_styling',
				'type'        => 'styling',
				'section'     => 'skyhaus_general_settings_breadcrumbs',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Styling', 'skyhaus' ),
				'selector'    => array(
					'normal'            => ".skyhaus-breadcrumbs",
					'hover'             => ".skyhaus-breadcrumbs:hover"
				),
				'fields'      => array(
					'normal_fields' => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
					'hover_fields'  => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
				),
			),
			array(
				'name'    		=> 'skyhaus_breadcrumbs_title_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_general_settings_breadcrumbs',
				'title'   		=> esc_html__( 'Breadcrumb Title', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_breadcrumbs_title_color',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_general_settings_breadcrumbs',
				'selector'   	=> 'format',
				'title'      	=> esc_html__( 'Title Color', 'skyhaus' ),
				'selector'   	=> ".skyhaus-breadcrumbs h2, .skyhaus-breadcrumbs h1, .skyhaus-breadcrumbs h1 span",
				'css_format' 	=> 'color: {{value}};',
			),
			array(
				'name'        	=> "skyhaus_breadcrumbs_title_typo",
				'type'        	=> 'typography',
				'section'     	=> "skyhaus_general_settings_breadcrumbs",
				'title'       	=> esc_html__( 'Title Typography', 'skyhaus' ),
				'css_format'  	=> 'typography',
				'selector'    	=> ".skyhaus-breadcrumbs h2, .skyhaus-breadcrumbs h1, .skyhaus-breadcrumbs h1 span",
			),
			array(
				'name'    		=> 'skyhaus_breadcrumbs_subtitle_heading',
				'type'    		=> 'heading',
				'section' 		=> 'skyhaus_general_settings_breadcrumbs',
				'title'   		=> esc_html__( 'Breadcrumb Subtitle', 'skyhaus' ),
			),
			array(
				'name'       	=> 'skyhaus_breadcrumbs_subtitle_color',
				'type'       	=> 'color',
				'section' 		=> 'skyhaus_general_settings_breadcrumbs',
				'selector'   	=> 'format',
				'title'      	=> esc_html__( 'Subtitle Color', 'skyhaus' ),
				'selector'   	  => ".skyhaus-breadcrumbs .breadcrumb .active, .breadcrumb, .breadcrumb a::after,.skyhaus-breadcrumbs .breadcrumb a",
				'css_format' 	  => 'color: {{value}};',
			),
			array(
				'name'        	=> "skyhaus_breadcrumbs_subtitle_typo",
				'type'        	=> 'typography',
				'section'     	=> "skyhaus_general_settings_breadcrumbs",
				'title'       	=> esc_html__( 'Subtitle Typography', 'skyhaus' ),
				'css_format'  	=> 'typography',
				'selector'    	=> ".skyhaus-breadcrumbs .breadcrumb .active, .breadcrumb,.skyhaus-breadcrumbs .breadcrumb a",
			),
			array(
				'name'    			=> 'skyhaus_breadcrumbs_delimitator_heading',
				'type'    			=> 'heading',
				'section' 			=> 'skyhaus_general_settings_breadcrumbs',
				'title'   			=> esc_html__( 'Delimitator', 'skyhaus' ),
			),
			array(
				'name'       		=> 'skyhaus_breadcrumbs_delimitator_color',
				'type'       		=> 'color',
				'section' 			=> 'skyhaus_general_settings_breadcrumbs',
				'selector'   		=> 'format',
				'default'			=> 'rgba(0,150,57,0)',
				'title'      		=> esc_html__( 'Delimitator', 'skyhaus' ),
				'selector'   	  	=> ".skyhaus-breadcrumbs .row",
				'css_format' 	  	=> 'border-color: {{value}};',
			),

			// Preloader
			array(
				'name'  			=> "skyhaus_general_settings_preloader",
				'type'  			=> 'section',
				'panel' 			=> 'general_settings_panel',
				'title' 			=> esc_html__( 'Preloader', 'skyhaus' ),
			),
			array(
				'name'           	=> 'skyhaus_enable_preloader',
				'type'            	=> 'checkbox',
				'section'         	=> 'skyhaus_general_settings_preloader',
				'title'           	=> esc_html__( 'Preloader', 'skyhaus' ),
				'description'     	=> esc_html__('Enable or disable preloader', 'skyhaus'),
				'default'         	=> 0
			),
			array(
				'name'            	=> 'skyhaus_preloader_image',
				'type'            	=> 'image',
				'section'         	=> 'skyhaus_general_settings_preloader',
				'title'           	=> esc_html__( 'Image', 'skyhaus' )
			),
			array(
				'name'            => 'skyhaus_preloader_bg_color',
				'type'            => 'color',
				'section'         => 'skyhaus_general_settings_preloader',
				'title'           => esc_html__( 'Background Color', 'skyhaus' ),
				'default'         => '#000',
				'selector'    	  => ".skyhaus_preloader_holder",
				'css_format' 	  => 'background-color: {{value}};'
			),

			// Popup
			array(
				'name'  			=> "skyhaus_general_settings_popup",
				'type'  			=> 'section',
				'panel' 			=> 'general_settings_panel',
				'title' 			=> esc_html__( 'Popup', 'skyhaus' ),
			),
			array(
				'name'           	=> 'skyhaus_enable_popup',
				'type'            	=> 'checkbox',
				'section'         	=> 'skyhaus_general_settings_popup',
				'title'           	=> esc_html__( 'Popup', 'skyhaus' ),
				'description'     	=> esc_html__('Enable or disable popup', 'skyhaus'),
				'default'         	=> 0
			),
			array(
				'name'    			=> 'skyhaus_popup_design_heading',
				'type'    			=> 'heading',
				'section' 			=> 'skyhaus_general_settings_popup',
				'title'   			=> esc_html__( 'Design', 'skyhaus' ),
			),
			array(
				'name'            	=> 'skyhaus_popup_image',
				'type'            	=> 'image',
				'section'         	=> 'skyhaus_general_settings_popup',
				'title'           	=> esc_html__( 'Image', 'skyhaus' ),
				'description' 	  	=> esc_html__('Set your popup image', 'skyhaus'),
			),
			array(
				'name'            	=> 'skyhaus_popup_content',
				'type'            	=> 'textarea',
				'section'         	=> 'skyhaus_general_settings_popup',
				'default'         	=> esc_html__( 'Add custom text here or remove it', 'skyhaus' ),
				'title'           	=> esc_html__( 'Content', 'skyhaus' ),
				'description'     	=> esc_html__( 'Set texts and images to the content.', 'skyhaus' ),
			),
			array(
				'name'    			=> 'skyhaus_popup_settings_heading',
				'type'    			=> 'heading',
				'section' 			=> 'skyhaus_general_settings_popup',
				'title'   			=> esc_html__( 'Settings', 'skyhaus' ),
			),
			array(
                'name'       		=> 'skyhaus_popup_url',
                'type'     			=> 'text',
                'title'    			=> esc_html__('URL', 'skyhaus'),
                'section'       	=> 'skyhaus_general_settings_popup',
            ),
			array(
				'name'            	=> 'skyhaus_popup_expiring_cookie',
				'type'            	=> 'select',
				'section'         	=> 'skyhaus_general_settings_popup',
				'title'           	=> esc_html__('Expiring Cookie', 'skyhaus' ),
				'description'     	=> esc_html__('Select the days for when the cookies to expire.', 'skyhaus'),
				'choices'         	=> array(
					'1' 	=> esc_html__( '1 Day', 'skyhaus' ),
					'3'  	=> esc_html__( '3 Days', 'skyhaus' ),
					'7'  	=> esc_html__( '1 Week', 'skyhaus' ),
					'30'  	=> esc_html__( '1 Month', 'skyhaus' ),
					'3000' 	=> esc_html__( 'Be Remembered', 'skyhaus' ),
				),
				'default'   		=> '1',
			),
			array(
				'name'            	=> 'skyhaus_popup_show_time',
				'type'            	=> 'select',
				'section'         	=> 'skyhaus_general_settings_popup',
				'title'           	=> esc_html__('Show Popup', 'skyhaus' ),
				'description'     	=> esc_html__('Select a specific time to show the popup.', 'skyhaus'),
				'choices'         	=> array(
					'5000' 	=> esc_html__( '5 seconds', 'skyhaus' ),
					'10000' => esc_html__( '10 seconds', 'skyhaus' ),
					'20000' => esc_html__( '20 seconds', 'skyhaus' )
				),
				'default'   		=> '5000',
			),

            // Contact Information
			array(
				'name'  => "skyhaus_general_settings_contact",
				'type'  => 'section',
				'panel' => 'general_settings_panel',
				'title' => esc_html__( 'Contact Information', 'skyhaus' ),
			),

			array(
                'name'       	=> 'skyhaus_contact_address',
                'type'     		=> 'text',
                'title'    		=> esc_html__('Address', 'skyhaus'),
                'section'       => 'skyhaus_general_settings_contact',
            ),
            array(
                'name'       	=> 'skyhaus_contact_email',
                'type'     		=> 'text',
                'title'    		=> esc_html__('Email', 'skyhaus'),
                'section'       => 'skyhaus_general_settings_contact',
            ),
            array(
                'name'       	=> 'skyhaus_contact_phone',
                'type'     		=> 'text',
                'title'    		=> esc_html__('Phone', 'skyhaus'),
                'section'       => 'skyhaus_general_settings_contact',
            ),

			//Back to top
			array(
				'name'  => "skyhaus_general_settings_back_to_top",
				'type'  => 'section',
				'panel' => 'general_settings_panel',
				'title' => esc_html__( 'Back to Top', 'skyhaus' ),
			),
			array(
				'name'            => 'skyhaus_backtotop_status',
				'type'            => 'checkbox',
				'section'         => 'skyhaus_general_settings_back_to_top',
				'title'           => esc_html__( 'Back to Top Button Status', 'skyhaus' ),
				'default'         => 1
			),
			array(
				'name'            => 'skyhaus_backtotop_bg_color',
				'type'            => 'color',
				'section'         => 'skyhaus_general_settings_back_to_top',
				'title'           => esc_html__( 'Background Color', 'skyhaus' ),
				'default'         => '#2695FF',
				'selector'    	  => ".skyhaus-back-to-top",
				'css_format' 	  => 'background-color: {{value}};'
			),
			array(
				'name'            => 'skyhaus_backtotop_icon_color',
				'type'            => 'color',
				'section'         => 'skyhaus_general_settings_back_to_top',
				'title'           => esc_html__( 'Icon Color', 'skyhaus' ),
				'default'         => '#FFF',
				'selector'    	  => ".skyhaus-back-to-top, .skyhaus-back-to-top.skyhaus-is-visible:visited",
				'css_format' 	  => 'color: {{value}};'
			),
			array(
				'name'            => 'skyhaus_backtotop_bg_color_hover',
				'type'            => 'color',
				'section'         => 'skyhaus_general_settings_back_to_top',
				'title'           => esc_html__( 'Background Color (Hover)', 'skyhaus' ),
				'default'         => '#222',
				'selector'    	  => ".skyhaus-back-to-top:hover",
				'css_format' 	  => 'background-color: {{value}};'
			),
			array(
				'name'            => 'skyhaus_backtotop_icon_color_hover',
				'type'            => 'color',
				'section'         => 'skyhaus_general_settings_back_to_top',
				'title'           => esc_html__( 'Icon Color (Hover)', 'skyhaus' ),
				'default'         => '#FFF',
				'selector'    	  => ".skyhaus-back-to-top:hover",
				'css_format' 	  => 'color: {{value}};'
			),
			array(
				'name'            	=> 'skyhaus_backtotop_radius',
				'type'            	=> 'css_ruler',
				'section'    		=> 'skyhaus_general_settings_back_to_top',
				'device_settings' 	=> true,
				'css_format'      	=> array(
					'top'    => 'border-bottom-right-radius: {{value}};',
					'right'  => 'border-top-right-radius: {{value}};',
					'bottom' => 'border-bottom-left-radius: {{value}};',
					'left'   => 'border-top-left-radius: {{value}};',
				),
				'selector'        	=> "body .skyhaus-back-to-top",
				'label'           	=> esc_html__( 'Border Radius', 'skyhaus' ),
			),
		);

		return array_merge( $configs, $config );
	}
}

add_filter( 'skyhaus/customizer/config', 'skyhaus_customizer_general_settings_config' );
