<?php

class Skyhaus_Builder_Header_Settings {
	public $id = 'header_settings';

	function customize() {
		$section = 'header_settings';

		return array(
			array(
				'name'     		=> $section,
				'type'     		=> 'section',
				'panel'    		=> 'header_settings',
				'priority' 		=> 299,
				'title'    		=> esc_html__( 'Settings', 'skyhaus' ),
			),
			array(
				'name'          => 'skyhaus_general_settings_look_htransparent',
				'type'          => 'checkbox',
				'section'   	=> $section,
				'title'         => esc_html__( 'Transparent Header', 'skyhaus' ),
				'description'   => esc_html__('Enable or disable Transparent Header', 'skyhaus'),
				'default'       => 0,
			),
			array(
				'name'      	=> 'skyhaus_is_nav_sticky',
				'type'      	=> 'checkbox',
				'section'   	=> $section,
				'title'     	=> esc_html__( 'Fixed Navigation menu?', 'skyhaus' ),
				'description'   => esc_html__('Enable or disable Sticky Header', 'skyhaus'),
			),
		);
	}
}

Skyhaus_Customize_Layout_Builder()->register_item( 'header', new Skyhaus_Builder_Header_Settings() );
