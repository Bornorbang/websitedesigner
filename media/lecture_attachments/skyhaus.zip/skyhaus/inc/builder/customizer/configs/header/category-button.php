<?php

class Skyhaus_Builder_Category_Button {

	public $id = 'category_button';

	/**
	 * Register Builder item
	 *
	 * @return array
	 */
	function item() {
		return array(
			'name'    => esc_html__( 'Category Button', 'skyhaus' ),
			'id'      => $this->id,
			'col'     => 0,
			'width'   => '4',
			'section' => 'header_category_button',
		);
	}

	/**
	 * Optional, Register customize section and panel.
	 *
	 * @return array
	 */
	function customize() {
		$fn     = array( $this, 'render' );
		$config = array(
			array(
				'name'     => 'header_category_button',
				'type'     => 'section',
				'panel'    => 'header_settings',
				'priority' => 201,
				'title'    => esc_html__( 'Category Button', 'skyhaus' ),
			),

			array(
				'name'    => 'header_category_button_heading',
				'type'    => 'heading',
				'section' => 'header_category_button',
				'title'   => esc_html__( 'The Category Navigation can be populated from Appearance - Menus - Display location - Category Button', 'skyhaus' )
			),
			array(
				'name'            => 'skyhaus_category_button_placeholder',
				'type'            => 'text',
				'section'         => 'header_category_button',
				'render_callback' => $fn,
				'label'           => esc_html__( 'Placeholder', 'skyhaus' ),
				'default'         => esc_html__( 'Catalog', 'skyhaus' ),
				'priority'        => 10,
			),

			array(
				'name'            => 'skyhaus_category_button_width',
				'type'            => 'slider',
				'device_settings' => true,
				'section'         => 'header_category_button',
				'selector'        => ".skyhaus_category_button .category_button_wrap",
				'css_format'      => 'width: {{value}};',
				'label'           => esc_html__( 'Button Width', 'skyhaus' ),
				'description'     => esc_html__( 'Note: The width can not greater than grid width.', 'skyhaus' ),
				'priority'        => 15,
			),

			array(
				'name'            => 'skyhaus_category_button_height',
				'type'            => 'slider',
				'device_settings' => true,
				'section'         => 'header_category_button',
				'min'             => 25,
				'step'            => 1,
				'max'             => 100,
				'selector'        => ".skyhaus_category_button .category_button_wrap",
				'css_format'      => 'height: {{value}};',
				'label'           => esc_html__( 'Button Height', 'skyhaus' ),
				'priority'        => 20,
			),

			array(
				'name'        => 'skyhaus_category_button_font_size',
				'type'        => 'typography',
				'section'     => 'header_category_button',
				'selector'    => ".skyhaus_category_button .category_button_title",
				'css_format'  => 'typography',
				'label'       => esc_html__( 'Button Text Typography', 'skyhaus' ),
				'priority'    => 35,
			),

			array(
				'name'        => 'skyhaus_category_button_styling',
				'type'        => 'styling',
				'section'     => 'header_category_button',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Button Styling', 'skyhaus' ),
				'selector'    => array(
					'normal'            	=> ".skyhaus_category_button .category_button_title",
					'hover'             	=> ".skyhaus_category_button .category_button_wrap:hover",
					'normal_text_color' 	=> ".skyhaus_category_button .category_button_title",
					'hover_text_color' 		=> ".skyhaus_category_button .menu-item > a:hover",
					'normal_bg_color' 		=> ".skyhaus_category_button .category_button_wrap",
					'normal_border_style' 	=> ".skyhaus_category_button .category_button_wrap",
					'normal_border_width' 	=> ".skyhaus_category_button .category_button_wrap",
					'normal_border_color' 	=> ".skyhaus_category_button .category_button_wrap",
					'normal_border_radius' 	=> ".skyhaus_category_button .category_button_wrap",
					'normal_box_shadow' 	=> ".skyhaus_category_button .category_button_wrap",
				),
				'default'     => array(
					'normal' => array(
						'text_color' => '#fff',
						'bg_color'	 => '#5ab210'
					),
				),
				'fields'      => array(
					'normal_fields' => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					),
					'hover_fields'  => array(
						'link_color'    => false,
						'padding'       => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'border_radius' => false,
					),
				),
				'priority'        => 40,
			),

		);

		// Item Layout.
		return array_merge( $config, skyhaus_header_layout_settings( $this->id, 'header_category_button' ) );
	}

	/**
	 * Optional. Render item content
	 */
	function render() {
		$placeholder = Skyhaus()->get_setting( 'skyhaus_category_button_placeholder' );
		$placeholder = sanitize_text_field( $placeholder );

		echo '<div class="skyhaus_category_button">';
                echo '<button class="category_button_wrap">';
                echo '<span class="category_button_title">'.esc_html($placeholder).'</span></button>';
                echo '<ul class="button_dropdown">';
                    if ( has_nav_menu( 'hb-category-button' ) ) {
                        $defaults = array(
                            'menu'            => '',
                            'container'       => false,
                            'container_class' => '',
                            'container_id'    => '',
                            'menu_class'      => 'menu',
                            'menu_id'         => '',
                            'echo'            => true,
                            'fallback_cb'     => false,
                            'before'          => '',
                            'after'           => '',
                            'link_before'     => '',
                            'link_after'      => '',
                            'items_wrap'      => '%3$s',
                            'depth'           => 0,
                            'walker'          => ''
                          );
                          $defaults['theme_location'] = 'hb-category-button';
                          wp_nav_menu( $defaults );
                    }
                echo '</ul>';
        echo '</div>';
	}
}

Skyhaus_Customize_Layout_Builder()->register_item( 'header', new Skyhaus_Builder_Category_Button() );
