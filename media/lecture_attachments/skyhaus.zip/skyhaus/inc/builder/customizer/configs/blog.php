<?php
if ( ! function_exists( 'skyhaus_customizer_blog_config' ) ) {
	function skyhaus_customizer_blog_config( $configs ) {

		$section = 'skyhaus_blog';

		$config = array(
			// Panel
			array(
				'name'     => 'blog_panel',
				'type'     => 'panel',
				'priority' => 22,
				'title'    => esc_html__( 'Blog Settings', 'skyhaus' ),
			),

			// I. Blog Archive
			array(
				'name'  => "skyhaus_blog_archive",
				'type'  => 'section',
				'panel' => 'blog_panel',
				'title' => esc_html__( 'Blog Archive', 'skyhaus' ),
			),
			array(
				'name'            => 'skyhaus_blog_archive_layout',
				'type'            => 'radio_group',
				'section'         => 'skyhaus_blog_archive',
				'default'         => 'right-sidebar',
				'title'           => esc_html__( 'Blog Layout', 'skyhaus' ),
				'choices'         => array(
					'left-sidebar'  	=> esc_html__( 'Left Sidebar', 'skyhaus' ),
					'no-sidebar' 		=> esc_html__( 'Fullwidth', 'skyhaus' ),
					'right-sidebar'  	=> esc_html__( 'Right Sidebar', 'skyhaus' ),
				),
			),
			array(
				'name'        => 'skyhaus_blog_article_card_styling',
				'type'        => 'styling',
				'section'     => 'skyhaus_blog_archive',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Article Card Styling', 'skyhaus' ),
				'selector'    => '.skyhaus-article-wrapper .skyhaus-article-inner',
				'fields'      => array(
					'normal_fields' => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					)
				)
			),

			// II. Single Post
			array(
				'name'  => "skyhaus_blog_single",
				'type'  => 'section',
				'panel' => 'blog_panel',
				'title' => esc_html__( 'Blog Single Article', 'skyhaus' ),
			),
			array(
				'name'            => 'skyhaus_blog_single_layout',
				'type'            => 'radio_group',
				'section'         => 'skyhaus_blog_single',
				'default'         => 'no-sidebar',
				'title'           => esc_html__( 'Single Blog Layout', 'skyhaus' ),
				'choices'         => array(
					'left-sidebar'  	=> esc_html__( 'Left Sidebar', 'skyhaus' ),
					'no-sidebar' 		=> esc_html__( 'Fullwidth', 'skyhaus' ),
					'right-sidebar'  	=> esc_html__( 'Right Sidebar', 'skyhaus' ),
				),
			),
			array(
				'name'            => 'skyhaus_blog_single_featured_image',
				'type'            => 'checkbox',
				'section'         => 'skyhaus_blog_single',
				'default'         => 1,
				'title'           => esc_html__( 'Featured Image', 'skyhaus' ),
				'description'     => esc_html__( 'Show or Hide the featured image from blog post page', 'skyhaus' ),
			),
		);

		return array_merge( $configs, $config );
	}
}

add_filter( 'skyhaus/customizer/config', 'skyhaus_customizer_blog_config' );
