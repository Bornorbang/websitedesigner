<?php

class Skyhaus_Builder_Header_Sidebars {
	public $id = 'header_sidebars';

	function customize() {
		$section = 'header_sidebars';

		return array(
			array(
				'name'     => $section,
				'type'     => 'section',
				'panel'    => 'general_settings_panel',
				'priority' => 299,
				'title'    => esc_html__( 'Sidebars', 'skyhaus' ),
			),
			array(
				'name'             => 'skyhaus_general_sidebars',
				'type'             => 'repeater',
				'section'        	=> $section,
				'title'            => esc_html__( 'Custom Sidebars', 'skyhaus' ),
				'live_title_field' => 'title',
				'default'          => array(
					array(
						'title' => esc_html__( 'Header Burger Sidebar', 'skyhaus' ),
					),
				),
				'fields'           => array(
					array(
						'name'  => 'title',
						'type'  => 'text',
						'label' => esc_html__( 'Sidebar Name', 'skyhaus' ),
					),
				),
			),
		);
	}
}

Skyhaus_Customize_Layout_Builder()->register_item( 'header', new Skyhaus_Builder_Header_Sidebars() );
