<?php
if ( ! function_exists( 'skyhaus_customizer_404_config' ) ) {
	function skyhaus_customizer_404_config( $configs ) {

		$section = 'skyhaus_not_found';

		$config = array(
			array(
				'name'     => 'not_found_panel',
				'type'     => 'panel',
				'priority' => 22,
				'title'    => esc_html__( '404 Page Settings', 'skyhaus' ),
			),

			// Image.
			array(
				'name'  => "skyhaus_not_found_404",
				'type'  => 'section',
				'panel' => 'not_found_panel',
				'title' => esc_html__( '404 Image', 'skyhaus' ),
			),

			array(
				'name'            => 'skyhaus_not_found_404_img',
				'type'            => 'image',
				'section'         => 'skyhaus_not_found_404',
				'title'           => esc_html__( 'Image for 404 Not found page', 'skyhaus' ),
			),

			// Content.
			array(
				'name'  => "skyhaus_not_found_404_content",
				'type'  => 'section',
				'panel' => 'not_found_panel',
				'title' => esc_html__( '404 Content', 'skyhaus' ),
			),
			array(
				'name'            => 'skyhaus_page_404_heading',
				'type'            => 'textarea',
				'section'         => 'skyhaus_not_found_404_content',
				'title'           => esc_html__( 'Heading', 'skyhaus' ),
				'default'         => esc_html__( 'Sorry, this page does not exist!', 'skyhaus' ),
			),
			array(
				'name'            => 'skyhaus_page_404_paragraph',
				'type'            => 'textarea',
				'section'         => 'skyhaus_not_found_404_content',
				'title'           => esc_html__( 'Paragraph (sub-heading)', 'skyhaus' ),
				'default'         => esc_html__( 'The link you clicked might be corrupted, or the page may have been removed.', 'skyhaus' ),
			),

		);

		return array_merge( $configs, $config );
	}
}

add_filter( 'skyhaus/customizer/config', 'skyhaus_customizer_404_config' );
