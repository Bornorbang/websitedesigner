<?php
/**
 * Get comments template
 *
 * @package skyhaus
 */

get_template_part('templates/comments/templates/comments');