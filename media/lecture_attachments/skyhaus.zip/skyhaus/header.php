<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Skyhaus
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=10.0, user-scalable=yes">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php
if ( function_exists( 'wp_body_open' ) ) {
    wp_body_open();
}
?>
<div id="page">
	<a class="skip-link screen-reader-text" href="#skyhaus-site-content"><?php esc_html_e( 'Skip to content', 'skyhaus' ); ?></a>
	<?php
	do_action( 'skyhaus/site-start/before' );
	
		/**
		 * Site start
		 *
		 * Hooked
		 *
		 * @see skyhaus_customize_render_header - 10
		 * @see skyhaus_Page_Header::render - 35
		 */
		do_action( 'skyhaus/site-start' );
	
	/**
	 * Hook before main content
	 */
	do_action( 'skyhaus/before-site-content' );
	?>
	<div id="skyhaus-site-content" >
		<div>
			<div>
				<?php do_action( 'skyhaus/main/before' );
