        </div>
        <?php
        /**
         * Hook before site content
         *
         */
        do_action( 'skyhaus/site-end' );


        ?>
      </div>
    </div>
  </div>
<?php wp_footer(); ?>

</body>
</html>